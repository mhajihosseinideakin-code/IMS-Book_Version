# CHANGELOG — Stabilizing MRC Implementation

This entry covers the work implementing the book's stabilizing-MRC
construction as a distinct model, per the technical review request.
Development/process notes only; no revision-history language appears
in user-facing application text or scientific reports.

## Added

- `ims_platform/models/stabilizing_mrc.py` — `StabilizingMRCModel`, a
  new 4-state `DynamicalSystem` (`i_l, v_b, sigma, v_o`) implementing
  the book's internal-integrator-target-manifold stabilizing MRC
  construction, registered under the id `stabilizing_mrc`.
- `ims_platform/case/registry.py` — registered `stabilizing_mrc`
  (`StabilizingMRCModel`) and `electrical_constraint_mrc`
  (the pre-existing `ConverterCPLPaper`, which was implemented and
  correctly documented but was not previously exposed through the
  case registry at all).
- `tests/test_stabilizing_mrc.py` — 12 new tests, described below.

## Findings from inspecting the existing implementation

- `models/converter_cpl_paper.py` (`ConverterCPLPaper`) was found to
  **already** correctly implement and document the electrical-
  constraint manifold (`e_m = v_b - v_o + R*i_l`) as a diagnostic
  reference, including its own docstring already stating the
  structurally positive tangential mode and the resulting non-
  stabilization finding. No relabeling or reinterpretation of this
  existing model was needed or performed; it was not previously
  registered in `case/registry.py` at all (added, unchanged).
- `control/mrc.py` already documents an EARLIER naming correction
  (`ManifoldReshapingControl` → `ScheduledLQRControl`) unrelated to
  this task — that class is a manifold-scheduled LQR design
  (Conventional Control Library), not IMS-native MRC. Left untouched.
- `control/mrc_synthesis.py` (`MRCSynthesizer`) is a generic,
  model-independent four-step symbolic synthesis engine, already
  present and already used to validate `ConverterCPLPaper` against a
  published control law. `StabilizingMRCModel` was built specifically
  to work with this existing engine (via `symbolic_dynamics` /
  `symbolic_manifold_constraint`), rather than writing a second,
  parallel synthesis mechanism.

## Verified (independently, not merely asserted)

- `de_Sigma/dt = -k_m*e_Sigma`: verified by (a) direct symbolic
  substitution of the given control law into the plant, and (b)
  running `StabilizingMRCModel` through the platform's own
  `MRCSynthesizer` and confirming the *independently derived* control
  law is symbolically identical (`sympy.simplify` to exactly 0) and
  numerically identical over 20 random parameter trials.
- Closed-form equilibrium (`v_b*=v_nom`, `i_l*=P/v_nom`,
  `sigma*=(R+R_v)*P/(K_i*v_nom)`) verified against an independent
  `sympy.solve` of the reduced dynamics (not merely substituted back
  in), and against direct evaluation of all four original state
  derivatives (including the closed-loop control law itself) at that
  point.
- Characteristic-polynomial coefficients (a2, a1, a0) verified against
  a freshly re-derived Jacobian/characteristic-polynomial computation
  (not copied from the model's own formula).
- Nominal poles at the benchmark parameter set computed independently
  via `numpy.roots` and matched to the specified values
  (-60.0849, -178.2909±j436.0281) to 1e-3.
- Routh-Hurwitz conditions checked individually with margins, not a
  single flag; confirmed a genuinely destabilizing `K_i=5000` is
  flagged by the RH condition *and* independently produces a real
  right-half-plane pole via `numpy.roots`.
- Electrical-constraint reference's eigenvalue set `{-k_m, 0,
  P/(C*v_b*^2)}` re-derived independently and locked in with a
  regression test guarding against ever "fixing" it into looking
  stabilizing.
- Distance certificate (`dist(x,M_Sigma)^2 = e_Sigma^2/q`,
  `q=R_v^2+K_i^2+1`) and the `dV/dt=-2*k_m*V` identity for
  `V=e_Sigma^2`, verified via the chain rule applied to the
  already-verified residual identity.

## Explicitly NOT implemented in this delivery

See COMPLETION_REPORT.md for the full, itemized breakdown. In summary:
Mode B (finite-bandwidth/sampled actuator model), the Droop/EFL/
stabilizing-MRC benchmark simulation and its reported metrics, the
recoverability-classification overhaul (items 9-10 of the review), and
full platform-wide integration (API schemas, frontend state/plots,
report generation, network-level enforcement) were not implemented.
These are recorded as "Not implemented," not silently assumed to work.
